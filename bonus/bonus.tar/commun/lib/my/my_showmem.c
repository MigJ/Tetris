/*
** my_showmem.c for emacs in /home/detroy_j/delivery/lib
** 
** Made by jean-baptiste detroyes
** Login   <detroy_j@epitech.net>
** 
** Started on  Tue Oct 11 10:54:28 2016 jean-baptiste detroyes
** Last update Tue Oct 11 10:54:49 2016 jean-baptiste detroyes
*/

int	my_showmem(char *str, int size)
{
  return (0);
}

/*
** my_time.h for  in /home/joubert/delivery/PSU_2016_tetris
** 
** Made by Joubert Miguel
** Login   <miguel.joubert@epitech.eu>
** 
** Started on  Fri Mar  3 18:57:24 2017 Joubert Miguel
** Last update Fri Mar  3 19:12:23 2017 Joubert Miguel
*/

#ifndef _MY_TIME_
# define _MY_TIME_

typedef struct s_my_time
{
  int		minuts;
  int		seconds;
}t_my_time;

#endif /* _MY_TIME_ */

/*
** actions.h for  in /home/joubert/delivery/PSU_2016_tetris
** 
** Made by Joubert Miguel
** Login   <miguel.joubert@epitech.eu>
** 
** Started on  Fri Mar  3 19:56:53 2017 Joubert Miguel
** Last update Sun Mar 19 17:13:29 2017 Joubert Miguel
*/

#ifndef _ACTIONS_H_
# define _ACTIONS_H_

typedef struct s_params
{
  int           score_count;
  int           key;
  int           drop;
  int           new;
  int           color;
  int		waitt;
}t_params;

#endif /* _ACTIONS_H_ */

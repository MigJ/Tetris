/*
** my_showstr.c for emacs in /home/detroy_j/delivery/lib
** 
** Made by jean-baptiste detroyes
** Login   <detroy_j@epitech.net>
** 
** Started on  Tue Oct 11 10:53:43 2016 jean-baptiste detroyes
** Last update Tue Oct 11 10:54:12 2016 jean-baptiste detroyes
*/

int	my_showstr(char *str)
{
  return (0);
}
